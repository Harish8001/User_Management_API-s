package com.book.diningtable;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookDiningTableUpdatedApplicationTests {

	@Test
	void contextLoads() {
	}

}
