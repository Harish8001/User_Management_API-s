package com.book.diningtable.auth;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.book.diningtable.user.Role;
import com.book.diningtable.user.UserEntity;
import com.book.diningtable.user.UserRepository;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
  private final AuthenticationManager am;
  private final UserRepository repo;
  private final PasswordEncoder encoder;
  private final JwtService jwt;
  public AuthController(AuthenticationManager am, UserRepository repo, PasswordEncoder encoder, JwtService jwt){
    this.am = am; this.repo = repo; this.encoder = encoder; this.jwt = jwt;
  }

  
  @PostMapping("/register")
  public ResponseEntity<?> register(@RequestBody Map<String,String> req){
    if(repo.existsByUsername(req.get("username"))) return ResponseEntity.badRequest().body(Map.of("error","exists"));
    var u = UserEntity.builder().username(req.get("username")).password(encoder.encode(req.get("password"))).role(Role.USER).build();
    repo.save(u);
    return ResponseEntity.ok(Map.of("status","created"));
  }

  @PostMapping("/login")
  public ResponseEntity<?> login(@RequestBody Map<String,String> req){
    am.authenticate(new UsernamePasswordAuthenticationToken(req.get("username"), req.get("password")));
    var token = jwt.generate(req.get("username"), Map.of("role","USER"));
    return ResponseEntity.ok(Map.of("token", token));
  }
  

  

}
