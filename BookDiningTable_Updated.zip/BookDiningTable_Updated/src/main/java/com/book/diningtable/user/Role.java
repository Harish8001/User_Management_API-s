package com.book.diningtable.user;

public enum Role {

	 USER,
	 ADMIN
}
