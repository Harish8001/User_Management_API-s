package com.book.diningtable;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookDiningTableUpdatedApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookDiningTableUpdatedApplication.class, args);
	}

}
