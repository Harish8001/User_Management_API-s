package com.book.diningtable.cofig;

import com.book.diningtable.user.UserRepository;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

@Service
public class DatabaseUserDetailsService implements UserDetailsService {
  private final UserRepository repo;
  public DatabaseUserDetailsService(UserRepository repo){this.repo = repo;}
  @Override
  public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
    var u = repo.findByUsername(username).orElseThrow(() -> new UsernameNotFoundException("Not found"));
    return User.withUsername(u.getUsername()).password(u.getPassword()).roles(u.getRole().name()).build();
  }
}
