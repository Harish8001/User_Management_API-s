package com.book.diningtable.endpoint;

import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.book.diningtable.auth.JwtUtil;
@RestController

@RequestMapping("/api")
public class BookDiningTable {
	@GetMapping("/search")
    public String searchUser(@RequestParam("name") String name) {
        return "Searching for user: " + name;
    }
	
	 @PostMapping("/login")
	    public String login(@RequestParam String username, @RequestParam String password) {
	        // Validate user credentials from DB
	        if ("user".equals(username) && "password".equals(password)) {
	            return JwtUtil.generateToken(username);
	        }
	        else {
	        	return "Ivaild credentials";
	        }
	    }

}



