package com.book.diningtable.auth;


import com.book.diningtable.auth.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
public class SecurityConfig {

    @Autowired
    private JwtFilter jwtFilter;

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.csrf().disable()
            .authorizeHttpRequests()
            .requestMatchers("/api/auth/login").permitAll() // make login public
            .anyRequest().authenticated()                   // all other endpoints require JWT
            .and()
            .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class); // use autowired filter

        return http.build();
    }
}
