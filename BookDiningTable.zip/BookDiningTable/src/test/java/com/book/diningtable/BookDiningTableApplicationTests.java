package com.book.diningtable;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookDiningTableApplicationTests {

	@Test
	void contextLoads() {
	}

}
